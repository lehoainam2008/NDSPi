#ifndef I2C_H
#define I2C_H
#define WIFI_STATUS 0x28
#define DEVICE_STATUS 0x29

void handleI2C();

#endif