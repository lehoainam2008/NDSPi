#ifndef GAMEPAD_H
#define GAMEPAD_H
#define B_UP 0x220
#define B_DOWN 0x221
#define B_LEFT 0x222
#define B_RIGHT 0x223
#define B_A 0x130
#define B_B 0x131
#define B_X 0x132
#define B_Y 0x133
#define B_STR 0x13c
#define B_SLC 0x13d
#define B_L 0x134
#define B_R 0x135
#define B_VOLUP 0x73
#define B_VOLDOWN 0x72
#include <pigpio.h>

void initgpio();
void handleGamepad() ;
void handlePWR();
void handleStandby();
void handleVolume();

#endif 