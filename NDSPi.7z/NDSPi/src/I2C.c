#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <pigpio.h>

void handleI2C() {
  int i2cHandle = i2cOpen(1, 0x28, 0);//WiFi Status
  int i2cHandle2 = i2cOpen(1, 0x27, 0);//Device Status 
  int i2cHandle3 = i2cOpen(1, 0x29, 0);//Shutdown
  bool prevWifiStatus = false;
  while (true) {
        std::ifstream statusFile("/sys/class/net/wlan0/operstate");
        std::string wifiStatus;
        std::getline(statusFile, wifiStatus);
        statusFile.close();
        bool currentWifiStatus = (wifiStatus == "up");
        if (currentWifiStatus != prevWifiStatus) {
            if (currentWifiStatus) {
                i2cWriteByte(i2cHandle, 0x01);
            } else {
                i2cWriteByte(i2cHandle, 0x00); 
            }
            prevWifiStatus = currentWifiStatus;
        }
        bool PowerCMD = i2cReadByte(i2cHandle3, 0x29)
        if (PowerCMD){
          PowerOn = false;
        } else {
          PowerOn = true;
        }
        if (PowerOn) {
          i2cWriteByte(i2cHandle2, 0x01);
        } else {
          i2cWriteByte(i2cHandle2, 0x00);
        }
    }
}