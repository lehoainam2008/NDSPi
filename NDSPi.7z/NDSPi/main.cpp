#include <pigpio.h>
#include "../src/gamepad.h"
#include "../src/I2C.h"
#include <iostream>
#include <linux/input.h>
#include <fcntl.h>
#include <unistd.h>
#include <fstream>
#include <string>

int VolUp = 0;
int VolDown = 1;
//int Pwr = 4;
int Standby = 5;
//int ERROR = 6; 
int GPIO22 = 22;
int GPIO23 = 23;
int GPIO24 = 24;
int GPIO25 = 25;
int GPIO26 = 26;
int GPIO27 = 27;
bool PowerOn = true;
bool Pwr = true;


int main() {
  initgpio();
  handleGamepad() ;
  handlePWR();
  handleStandby();
  handleVolume();
  handleI2C();
}
