#!/bin/bash

echo 0 > /sys/class/gpio/gpio6/value
echo 6 > /sys/class/gpio/unexport